<?php /* Template Name: Home Page */ ?>
<?php get_header(); ?>

<!-- Banner -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <figure class=" main-banner">
                <img class="img-fluid" alt="" src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" />
            </figure>
        </div>
    </div>
</div>
<!-- Banner End -->

<!-- Content -->
<div class="container pt-5 pb-4">
    <div class="row justify-content-center">
        <div class="col-md-9 text-center">
            <section id="homepage-page">
               <hr>
                <?php 
 $args = array(
                        'category_name'          => 'main-page',
                        'order'                  => 'ASC',
                        'posts_per_page'         => '2',
                        'orderby'                => 'date',
                    );

                    // The Query
                    $query = new WP_Query( $args );

                    // The Loop
                    if ( $query->have_posts() ) {
                        while ( $query->have_posts() ) {
                            $query->the_post();
                            // do something
                            ?>
                            <h2 class="mb-4 mt-5 pt-5">
                    <?php the_title(); ?>
                </h2>
                           <p id="homepage" class="mb-5">
                    <?php the_content(); ?>
                </p>
                            <?php
                        }
                    } else {
                        // no posts found
                        echo "nothing";
                    }
                wp_reset_postdata();
                
                ?>
                
               
            </section>
        </div>
    </div>
</div>
       
    <div class="container pb-5">
        <div class="row">
            <div class="col-12">
                <section>
                    <h2 class="pb-5 mb-4 text-center news-events">News &amp; Events</h2>
                    <div class="center-facebook">
                        <!-- Facebook Feed -->
                        <a href="#fb-skip" class="sr-only sr-only-focusable text-light bg-dark p-2">Skip Facebook Feed</a>
                        <div class="fb-page" data-width="500" data-height="700" data-href="https://www.facebook.com/AchillesOttawaRunClub/ " data-tabs="timeline " data-small-header="false " data-adapt-container-width="true " data-hide-cover="false " data-show-facepile="true">
                        <blockquote cite="https://www.facebook.com/AchillesOttawaRunClub/ " class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/AchillesOttawaRunClub/ ">Achilles Ottawa</a></blockquote>
                        </div>
                        <div id="fb-skip"></div>
                    </div>
                   <!-- Facebook Feed End -->
                </section>
            </div>
        </div>
    </div>
    <!-- Content End -->

<?php get_footer(); ?>