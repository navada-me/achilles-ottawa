<?php


add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-header' );


//custom logo
add_theme_support( 'custom-logo', array(
	'height'      => 275, // set to your dimensions
	'width'       => 400,
	'flex-height' => true,
	'flex-width'  => true,
) );

// Register Custom Navigation Walker
require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

// Theme Setup
function wpbasics_theme_setup(){
    
    //Nav Menus
    register_nav_menus (array(
	'primary' => __( 'Primary Menu', 'achilles' ),
    ) );
}
add_action( 'after_setup_theme','wpbasics_theme_setup');

function custom_scripts() {
        wp_enqueue_style( 'custom-style', get_stylesheet_uri() );
        wp_enqueue_style( 'bootstrap-style' , 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css' );
        wp_enqueue_script( 'custom-script', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js', array( 'jquery' ), false, true );
}
add_action( 'wp_enqueue_scripts', 'custom_scripts' );


$args = array( 'flex-width' => true,
              'width' => 1200,
              'flex-height' => true,
              'height' => 200,
              'default-image' => get_template_directory_uri() . '/images/header.jpg', );
add_theme_support( 'custom-header', $args );



//add menu classes





?>
