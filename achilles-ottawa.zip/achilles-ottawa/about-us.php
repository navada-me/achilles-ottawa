<?php /* Template Name: About Us */ ?>
<?php get_header(); ?>
   
    <!-- Content -->
    <div class="container pb-5">
       <div class="row">
           <div class="col-md-12">
                <section id="about-us-page">
                    <hr>
      <?php 
                    
                                       // WP_Query arguments
                    $args = array(
                        'pagename'=>'about-achilles-ottawa',
                        'posts_per_page'         => '1'
                    );

                    // The Query
                    $query = new WP_Query( $args );

                    // The Loop
                    if ( $query->have_posts() ) {
                        while ( $query->have_posts() ) {
                            $query->the_post();
                            // do something
                            ?>
                            <h2 class="text-md-center">
                    <?php the_title(); ?>
                </h2>
                <hr>
                
                <div class="section-content pl-sm-5 pr-sm-5">  
                <div class="row mt-5">
                <div class="col-md-12 mt-md-12">
                    <img class="mx-auto d-block pb-4" style="max-width: 100%;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/about-image.jpg" alt="Achilles Ottawa Logo">
                </div>    
                <div class="col-md-12 pl-md-12">    
                <p>
                    <?php the_content(); ?>
                </p>
                            <?php
                        }
                    } else {
                        // no posts found
                        echo "nothing";
                    }
                wp_reset_postdata();
                
                ?>
                        </div>
                    </div>
                    </div>
                </section>
           </div>
       </div>
    </div>

<?php get_footer(); ?>