<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Achilles Ottawa is a club whose vision is to empower runners who are blind and visually impaired along with their guides in an environment of support.">
    <meta name="keywords" content="visually,impaired,runners,ottawa,canada,running club,sighted guide">

    <title>Achillies Ottawa</title>

    <!-- Bootstrap Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">
    <!-- Font Awesome Styles -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/main.css">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <!-- Skip Navigation On Focus For Screenreaders -->
    <a href="#content" class="sr-only sr-only-focusable text-light bg-dark p-2">Skip To Main Content</a>
    <!-- Facebook page plugin Starts Here -->
    <div id="fb-root"></div>
    <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0';
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

    </script>
    <!-- Facebook page plugin ends Here -->

    <!-- Header -->
    <div class="container">
        <div class="row justify-content-center">
            <header class="col-lg-12">
                <!-- Logo Starts Here-->
                <figure class="d-flex justify-content-center">
                    <a href="index.php"><img class="mx-auto d-block w-50 main-logo pb-5 mt-5" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/achilles-ottawa-logo.jpg" alt="Achilles ottawa Logo"></a>
                    <h1>
                        <figcaption class="offScreen">Achilles Ottawa Logo</figcaption>
                    </h1>
                </figure>
                <!-- Logo Ends Here-->
            </header>
            <div>
                <!--row-->
            </div>
            <!--container-->


            <div class="container d-none d-lg-block d-xl-block d-md-block">
                <div class="row">
                
            <!-- Main Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark bg-dark float-left pb-0 mb-0 col-8">
                            
                                <?php 
                                wp_nav_menu( array(
                                    'menu' => 'primary',
                                    'depth' => 2,
                                    'container' => 'navbar-center',
                                    'container_id'=>'myTogglerNav',
                                    'menu_class' => 'navbar-nav m-auto',
                                    'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                                    'walker' => new wp_bootstrap_navwalker()
                                           )
                                           );?>
                            
                        </nav>
                        <!-- Main Navigation End -->

                        <!-- Social Navigation -->

                        <nav id="social-icons" class="navbar navbar-expand-md col-4 justify-content-end social-nav">
                            <ul class="navbar-nav flex-row">
                                <li class="nav-item"><a class="nav-link pr-4 pl-4 pb-0" href="https://twitter.com/AchillesOttawa"><span class="sr-only">Twitter</span><i class="fab fa-twitter fa-2x"></i></a></li>
                                <li class="nav-item"><a class="nav-link pr-4 pl-4  pb-0" href="https://www.facebook.com/AchillesOttawaRunClub"><span class="sr-only">Facebook</span><i class="fab fa-facebook-f fa-2x"></i></a></li>
                            </ul>
                        </nav>
                </div>
            </div>

        <!-- Mobile Navigation Goes here-->

        <div class="container">
            
                <div class="d-block d-sm-block d-md-none d-lg-none d-xl-none">


                        <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                            <!-- Brand -->
                            <a class="navbar-brand" href="#">Menu</a>

                            <!-- Toggler/collapsibe Button -->
                            <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                                <span class="navbar-toggler-icon"></span>
                              </button>

                            <!-- Navbar links -->
                            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                               <?php 
                                        wp_nav_menu( array(
                                            'menu' => 'primary',
                                            'depth' => 2,
                                            'container' => 'navbar-center',
                                            'container_id'=>'myTogglerNav',
                                            'menu_class' => 'navbar-nav m-auto',
                                            'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                                            'walker' => new wp_bootstrap_navwalker()
                                                   )
                                 );?>
                                 <nav class="navbar navbar-expand-md col-4 social-nav">
                                 <ul class="navbar-nav mr-auto">
                                    <li class="nav-item"><a class="nav-link pb-4" href="https://twitter.com/AchillesOttawa"><span class="sr-only">Twitter</span><i class="fab fa-twitter fa-2x"></i></a></li>
                                    <li class="nav-item"><a class="nav-link pb-0" href="https://www.facebook.com/AchillesOttawaRunClub"><span class="sr-only">Facebook</span><i class="fab fa-facebook-f fa-2x"></i></a></li>
                                </ul>
                        </nav>
                            </div>
                    </nav>    
                    </div>
                    </div>
                    <!--container-->



                    <!-- Header End -->
                </div>
                <!-- SKIP NAV GOES HERE -->
                <div id="content"></div>
